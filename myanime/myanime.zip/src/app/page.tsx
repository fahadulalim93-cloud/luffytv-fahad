"use client";

import { useEffect, useState, useSyncExternalStore, useMemo, useRef } from "react";
import { useAppStore, parseHash } from "@/components/anime/store";
import Navbar from "@/components/anime/navbar";
import HomePage from "@/components/anime/home-page";
import SearchPage from "@/components/anime/search-page";
import AnimeDetailPage from "@/components/anime/anime-detail";
import WatchPage from "@/components/anime/watch-page";
import GenrePage from "@/components/anime/genre-page";
import BookmarksPage from "@/components/anime/bookmarks-page";
import HistoryPage from "@/components/anime/history-page";
import AnimeHomePage from "@/components/anime/anime-home";
import MoviesPage from "@/components/anime/movies-page";
import TVPage from "@/components/anime/tv-page";
import MovieDetailPage from "@/components/anime/movie-detail";
import TVDetailPage from "@/components/anime/tv-detail";
import MovieWatchPage from "@/components/anime/movie-watch";
import TVWatchPage from "@/components/anime/tv-watch";
import MangaPage from "@/components/anime/manga-page";
import MangaDetailPage from "@/components/anime/manga-detail";
import MangaReader from "@/components/anime/manga-reader";

const emptySubscribe = () => () => {};
function useMounted() {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
}

// ================================================================
// CINEMATIC INTRO — Straw Hat Falling Through Darkness
// Pure black → hat falls slowly → stops → energy pulse → cracks → reveal
// Deep black, subtle straw warmth, neon blue/red energy, cinematic premium
// ================================================================

function PortalIntro({ onComplete }: { onComplete: () => void }) {
  const [phase, setPhase] = useState<'dark' | 'fall' | 'stop' | 'pulse' | 'crack' | 'reveal'>('dark');
  const onCompleteRef = useRef(onComplete);

  useEffect(() => { onCompleteRef.current = onComplete; });

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase('fall'),   1000),  // 1.0s darkness, then hat appears
      setTimeout(() => setPhase('stop'),   3200),  // hat falls 2.2s, then stops
      setTimeout(() => setPhase('pulse'),  3800),  // brief pause 0.6s, then pulse
      setTimeout(() => setPhase('crack'),  4200),  // cracks spread
      setTimeout(() => setPhase('reveal'), 4800),  // homepage revealed
      setTimeout(() => onCompleteRef.current(), 5400),
    ];
    return () => timers.forEach(clearTimeout);
  }, []);

  // Dust particles floating in the dark
  const dustParticles = useMemo(() =>
    Array.from({ length: 30 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: 0.5 + Math.random() * 2,
      duration: 4 + Math.random() * 6,
      delay: Math.random() * 3,
      opacity: 0.15 + Math.random() * 0.3,
    }))
  , []);

  // Trailing particles behind the hat
  const trailParticles = useMemo(() =>
    Array.from({ length: 24 }, (_, i) => ({
      id: i,
      offsetX: (Math.random() - 0.5) * 60,
      delay: Math.random() * 1.5,
      size: 1 + Math.random() * 3,
      duration: 1 + Math.random() * 1.5,
      color: i % 4 === 0 ? '#00A8E1' : i % 4 === 1 ? '#E11D48' : i % 4 === 2 ? '#67d8ef' : '#ffffff',
    }))
  , []);

  // Cracks spreading from center
  const cracks = useMemo(() =>
    Array.from({ length: 8 }, (_, i) => ({
      id: i,
      angle: (i * 45) + Math.random() * 20 - 10,
      length: 15 + Math.random() * 25,
      width: 1 + Math.random() * 2,
      delay: i * 0.04,
    }))
  , []);

  // Energy pulse particles
  const pulseParticles = useMemo(() =>
    Array.from({ length: 20 }, (_, i) => ({
      id: i,
      angle: (i / 20) * 360,
      speed: 80 + Math.random() * 120,
      size: 2 + Math.random() * 4,
      color: i % 3 === 0 ? '#00A8E1' : i % 3 === 1 ? '#E11D48' : '#ffffff',
      delay: Math.random() * 0.2,
    }))
  , []);

  // Background light streaks
  const lightStreaks = useMemo(() => [
    { id: 0, x: 20, angle: -15, color: 'rgba(0, 168, 225, 0.06)', delay: 0.3 },
    { id: 1, x: 70, angle: 10, color: 'rgba(225, 29, 72, 0.05)', delay: 0.6 },
    { id: 2, x: 45, angle: -5, color: 'rgba(0, 168, 225, 0.04)', delay: 0.9 },
  ], []);

  return (
    <div className="fixed inset-0 z-[9999] bg-black overflow-hidden">
      {/* Deep cinematic vignette */}
      <div className="intro-vignette" />

      {/* Floating dust particles — always visible until reveal */}
      {phase !== 'reveal' && (
        <div className="intro-dust-container">
          {dustParticles.map(p => (
            <div
              key={p.id}
              className="intro-dust"
              style={{
                left: `${p.x}%`,
                top: `${p.y}%`,
                width: `${p.size}px`,
                height: `${p.size}px`,
                '--dust-dur': `${p.duration}s`,
                '--dust-delay': `${p.delay}s`,
                opacity: p.opacity,
              } as React.CSSProperties}
            />
          ))}
        </div>
      )}

      {/* Subtle background light streaks (blue/red) during fall */}
      {(phase === 'fall' || phase === 'stop') && (
        <div className="intro-light-streaks">
          {lightStreaks.map(s => (
            <div
              key={s.id}
              className="intro-light-streak"
              style={{
                left: `${s.x}%`,
                transform: `rotate(${s.angle}deg)`,
                background: s.color,
                '--streak-delay': `${s.delay}s`,
              } as React.CSSProperties}
            />
          ))}
        </div>
      )}

      {/* ===== STRAW HAT — The main centerpiece ===== */}
      {(phase === 'fall' || phase === 'stop' || phase === 'pulse') && (
        <div className={`intro-hat-container ${phase === 'fall' ? 'intro-hat-falling' : phase === 'stop' ? 'intro-hat-stopped' : 'intro-hat-pulsing'}`}>
          {/* The straw hat shape — CSS-drawn */}
          <div className="intro-straw-hat">
            {/* Hat brim — wide ellipse */}
            <div className="intro-hat-brim" />
            {/* Hat crown — dome on top */}
            <div className="intro-hat-crown" />
            {/* Hat band — red stripe */}
            <div className="intro-hat-band" />
            {/* Rim light — cinematic edge lighting */}
            <div className="intro-hat-rimlight" />
            {/* Anime scene reflections on hat surface */}
            <div className="intro-hat-reflection" />
          </div>

          {/* Particle trail behind hat */}
          {phase === 'fall' && (
            <div className="intro-trail-particles">
              {trailParticles.map(p => (
                <div
                  key={p.id}
                  className="intro-trail-particle"
                  style={{
                    '--trail-offset': `${p.offsetX}px`,
                    '--trail-delay': `${p.delay}s`,
                    '--trail-dur': `${p.duration}s`,
                    width: `${p.size}px`,
                    height: `${p.size}px`,
                    backgroundColor: p.color,
                  } as React.CSSProperties}
                />
              ))}
            </div>
          )}

          {/* Soft glow under hat */}
          <div className={`intro-hat-glow ${phase === 'pulse' ? 'intro-hat-glow-intense' : ''}`} />
        </div>
      )}

      {/* ===== PULSE — energy explosion from hat ===== */}
      {(phase === 'pulse' || phase === 'crack') && (
        <>
          {/* Central energy pulse */}
          <div className="intro-pulse-core" />
          {/* Expanding shockwave ring */}
          <div className="intro-pulse-ring" />
          {/* Radial pulse particles */}
          {pulseParticles.map(p => (
            <div
              key={p.id}
              className="intro-pulse-particle"
              style={{
                '--pulse-angle': `${p.angle}deg`,
                '--pulse-speed': `${p.speed}px`,
                '--pulse-delay': `${p.delay}s`,
                width: `${p.size}px`,
                height: `${p.size}px`,
                backgroundColor: p.color,
              } as React.CSSProperties}
            />
          ))}
          {/* Screen shake */}
          <div className="intro-screen-shake" />
        </>
      )}

      {/* ===== CRACKS — glowing cracks spread across screen ===== */}
      {(phase === 'crack' || phase === 'reveal') && (
        <>
          {cracks.map(c => (
            <div
              key={c.id}
              className="intro-crack"
              style={{
                '--crack-angle': `${c.angle}deg`,
                '--crack-length': `${c.length}vw`,
                '--crack-width': `${c.width}px`,
                '--crack-delay': `${c.delay}s`,
              } as React.CSSProperties}
            />
          ))}
          {/* Homepage visible through cracks */}
          <div className={`intro-crack-portal ${phase === 'reveal' ? 'intro-crack-portal-open' : ''}`} />
        </>
      )}

      {/* ===== REVEAL — camera zooms through cracks ===== */}
      {phase === 'reveal' && (
        <>
          <div className="intro-reveal-flash" />
          <div className="intro-reveal-fade" />
        </>
      )}
    </div>
  );
}

export default function MainPage() {
  const { route, navigate } = useAppStore();
  const mounted = useMounted();
  const [showSplash, setShowSplash] = useState(true);
  const [splashComplete, setSplashComplete] = useState(false);

  // Hash-based routing
  useEffect(() => {
    const handleHash = () => {
      const newRoute = parseHash(window.location.hash);
      const current = useAppStore.getState().route;
      if (JSON.stringify(current) !== JSON.stringify(newRoute)) {
        useAppStore.setState({ route: newRoute });
      }
    };
    handleHash();
    window.addEventListener("hashchange", handleHash);
    return () => window.removeEventListener("hashchange", handleHash);
  }, []);

  // Keyboard shortcut: Cmd/Ctrl+K to focus search
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        navigate({ page: "search" });
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [navigate]);

  const handleSplashComplete = () => {
    setSplashComplete(true);
    setTimeout(() => setShowSplash(false), 500);
  };

  if (!mounted) {
    return (
      <div className="min-h-screen bg-[#0b1116] flex items-center justify-center">
        <div className="text-center space-y-5">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center mx-auto shadow-lg shadow-cyan-500/20 animate-pulse">
            <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="currentColor">
              <polygon points="5 3 19 12 5 21 5 3" />
            </svg>
          </div>
          <div className="space-y-1">
            <p className="text-cyan-400 text-sm font-bold">GoAnime</p>
            <p className="text-zinc-600 text-xs">Loading...</p>
          </div>
          <div className="w-32 h-1 bg-[#1a2530] mx-auto rounded-full overflow-hidden">
            <div className="h-full bg-cyan-500/60 animate-pulse rounded-full" style={{ width: "60%" }} />
          </div>
        </div>
      </div>
    );
  }

  const isWatchPage = route.page === "watch" || route.page === "movie-watch" || route.page === "tv-watch";
  const isMangaReader = route.page === "manga-read";

  const renderPage = () => {
    switch (route.page) {
      case "home": return <HomePage />;
      case "search": return <SearchPage initialQuery={route.query} />;
      case "anime": return <AnimeDetailPage animeId={route.id} />;
      case "watch": return <WatchPage animeId={route.id} episodeNum={route.episode} />;
      case "genre": return <GenrePage genre={route.genre} />;
      case "dub": return <AnimeHomePage />;
      case "bookmarks": return <BookmarksPage />;
      case "history": return <HistoryPage />;
      case "movies": return <MoviesPage />;
      case "tv": return <TVPage />;
      case "manga": return <MangaPage />;
      case "manga-detail": return <MangaDetailPage mangaId={route.id} />;
      case "manga-read": return <MangaReader mangaId={route.id} chapterId={route.chapterId} />;
      case "movie-detail": return <MovieDetailPage movieId={route.id} />;
      case "tv-detail": return <TVDetailPage tvId={route.id} />;
      case "movie-watch": return <MovieWatchPage movieId={route.id} />;
      case "tv-watch": return <TVWatchPage tvId={route.id} season={route.season} episode={route.episode} />;
      default: return <HomePage />;
    }
  };

  return (
    <>
      {/* Splash Screen */}
      {showSplash && (
        <div className={splashComplete ? "splash-scale-out" : ""}>
          <PortalIntro onComplete={handleSplashComplete} />
        </div>
      )}

      {/* Main Content */}
      <div className={`min-h-screen bg-[#0b1116] flex flex-col ${!showSplash ? "content-reveal" : "opacity-0"}`}>
        {!isMangaReader && <Navbar />}
        <main className={`max-w-[1400px] mx-auto px-4 lg:px-8 ${isMangaReader ? '' : 'pt-[75px]'} ${isWatchPage || isMangaReader ? "" : "pb-24 lg:pb-12"} flex-1`}>
          {renderPage()}
        </main>
        {!isWatchPage && !isMangaReader && (
          <footer className="border-t border-white/[0.04] mt-16 bg-[#0b1116]">
            <div className="max-w-[1400px] mx-auto px-4 lg:px-8 py-12">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                <div className="col-span-2 md:col-span-1">
                  <div className="flex items-center gap-2.5 mb-4">
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
                      <svg className="w-4.5 h-4.5 text-white" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3" /></svg>
                    </div>
                    <span className="text-base font-bold gradient-text">GoAnime</span>
                  </div>
                  <p className="text-[11px] text-zinc-500 leading-relaxed mb-4">All-in-one streaming platform for anime, movies, TV shows and manga. Content sourced from third-party providers.</p>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1.5 px-2.5 py-1.5 bg-white/[0.03] rounded-lg border border-white/[0.05]">
                      <svg className="w-4 h-4 text-emerald-400" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="currentColor" strokeWidth={1.5} fill="none" />
                      </svg>
                      <span className="text-[9px] font-bold text-zinc-400">TMDB</span>
                    </div>
                    <div className="flex items-center gap-1.5 px-2.5 py-1.5 bg-white/[0.03] rounded-lg border border-white/[0.05]">
                      <svg className="w-4 h-4 text-cyan-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z" />
                        <path d="M8 14s1.5 2 4 2 4-2 4-2" />
                      </svg>
                      <span className="text-[9px] font-bold text-zinc-400">AniList</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-zinc-300 mb-4 uppercase tracking-wider">Discover</h4>
                  <div className="space-y-2.5">
                    <button onClick={() => navigate({ page: "home" })} className="block text-xs text-zinc-500 hover:text-cyan-400 transition-colors">Home</button>
                    <button onClick={() => navigate({ page: "movies" })} className="block text-xs text-zinc-500 hover:text-cyan-400 transition-colors">Movies</button>
                    <button onClick={() => navigate({ page: "tv" })} className="block text-xs text-zinc-500 hover:text-cyan-400 transition-colors">TV Shows</button>
                    <button onClick={() => navigate({ page: "dub" })} className="block text-xs text-zinc-500 hover:text-cyan-400 transition-colors">Anime</button>
                    <button onClick={() => navigate({ page: "manga" })} className="block text-xs text-zinc-500 hover:text-cyan-400 transition-colors">Manga</button>
                  </div>
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-zinc-300 mb-4 uppercase tracking-wider">Account</h4>
                  <div className="space-y-2.5">
                    <button onClick={() => navigate({ page: "bookmarks" })} className="block text-xs text-zinc-500 hover:text-cyan-400 transition-colors">My List</button>
                    <button onClick={() => navigate({ page: "history" })} className="block text-xs text-zinc-500 hover:text-cyan-400 transition-colors">Watch History</button>
                  </div>
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-zinc-300 mb-4 uppercase tracking-wider">Support</h4>
                  <div className="space-y-2.5">
                    <span className="block text-xs text-zinc-600">GoAnime v4.0</span>
                    <span className="block text-xs text-zinc-600">We do not host any files</span>
                  </div>
                </div>
              </div>
              <div className="section-divider mt-10 mb-6" />
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                <p className="text-[10px] text-zinc-700">&copy; {new Date().getFullYear()} GoAnime. All rights reserved.</p>
                <p className="text-[10px] text-zinc-700">Powered by TMDB &amp; AniList &bull; Content from third-party providers</p>
              </div>
            </div>
          </footer>
        )}
      </div>
    </>
  );
}
